package com.Daos;

import java.sql.PreparedStatement;
import java.sql.SQLException;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementCallback;

public class TableDaos {
	
	private JdbcTemplate jdbcTemplate;

	
	
	public JdbcTemplate getJdbcTemplate() {
		return jdbcTemplate;
	}



	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}



	public int save(Registration r) {
		String sql="insert into recapknolwdge.miniproject values('"+r.getFname()+"','"+r.getSname()+"','"+r.getEmail()+"','"+r.getPhone()+"','"+r.getPassword()+"')";
		return jdbcTemplate.update(sql);
	}
//	public Boolean save(Registration r) {
//		String sql="insert into recaphibernate.miniproject values(?,?,?,?,?)";
//		  return jdbcTemplate.execute(sql,new PreparedStatementCallback<Boolean>(){  
//				@Override
//				public Boolean doInPreparedStatement(PreparedStatement p) throws SQLException, DataAccessException {
//					p.setString(1,r.getFname());
//					p.setString(2,r.getSname());
//					p.setString(3,r.getEmail());
//					p.setInt(4,r.getPhone());
//					p.setString(5,r.getPassword());
//					return p.execute();
//				}  
//			    });  
//				
//	}
	
}
