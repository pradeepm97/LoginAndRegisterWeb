package com.main;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLDataException;
import java.sql.SQLException;
import java.util.DuplicateFormatFlagsException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.Daos.Registration;
import com.Daos.TableDaos;
@WebServlet("/Main")
public class Main extends HttpServlet {
private static final long serialVersionUID = 1L;
@Override
protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	String pass1=req.getParameter("pass1");
	String pass2=req.getParameter("pass2");
	if(pass1.equalsIgnoreCase(pass2)) {
		String fname=req.getParameter("fname");
		String sname=req.getParameter("lname");
		String email=req.getParameter("email");
		int phone=Integer.parseInt(req.getParameter("phone"));
		ApplicationContext context=new ClassPathXmlApplicationContext("spring.xml");
		Registration r=(Registration) context.getBean("register");
		r.setFname(fname);
		r.setSname(sname);
		r.setEmail(email);
		r.setPhone(phone);
		r.setPassword(pass1);
		TableDaos daos=(TableDaos) context.getBean("tdao");
			if(daos.save(r)==1) {
				PrintWriter printWriter=resp.getWriter();
				resp.sendRedirect("http://localhost:8080/MiniprojectBuilt/index.html");
			}
		
		
	}else {
	System.out.println("registration not done..");				
	}
	
	
		
			
}

	
}
